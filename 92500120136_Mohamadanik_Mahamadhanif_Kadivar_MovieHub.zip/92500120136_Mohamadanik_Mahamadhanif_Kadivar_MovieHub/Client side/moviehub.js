/* MovieHub shared website features: movie collection, visitor counter and movie views. */
(function () {
  "use strict";

  const MOVIES_KEY = "moviehubMovies";
  const GENRES_KEY = "moviehubGenres";
  const ANALYTICS_KEY = "moviehubAnalytics";
  const VISIT_SESSION_KEY = "moviehubVisitRecorded";

  const defaultMovies = [
    { id: 1, title: "Avengers Endgame", genre: "Action", year: 2019, rating: 5, poster: "Avengers Endgame Poster.webp" },
    { id: 2, title: "Interstellar", genre: "Sci-Fi", year: 2014, rating: 5, poster: "https://m.media-amazon.com/images/I/91kFYg4fX3L._AC_SY679_.jpg" },
    { id: 3, title: "3 Idiots", genre: "Comedy", year: 2009, rating: 4, poster: "3 idiots movie poster.jpg" },
    { id: 4, title: "Titanic", genre: "Romance", year: 1997, rating: 5, poster: "titanic movie poster.webp" },
    { id: 5, title: "The Pursuit of Happyness", genre: "Drama", year: 2006, rating: 5, poster: "the pursuit of happyness poster.webp" },
    { id: 6, title: "Atonement", genre: "Drama", year: 2007, rating: 4, poster: "https://image.tmdb.org/t/p/w500/5aXG0B3TYTpQsodXzvYCk8e2m0G.jpg" },
    { id: 7, title: "Zindagi Na Milegi Dobara", genre: "Drama", year: 2011, rating: 5, poster: "https://placehold.co/400x600/1f2937/ffffff?text=Zindagi+Na+Milegi+Dobara" },
    { id: 8, title: "Chhichhore", genre: "Comedy", year: 2019, rating: 4, poster: "chhichhore movie poster.jpg" },
    { id: 9, title: "Batman v Superman", genre: "Action", year: 2016, rating: 4, poster: "https://image.tmdb.org/t/p/w500/5UsK3grJvtQrtzEgqNlDljJW96w.jpg" },
    { id: 10, title: "The Martian", genre: "Sci-Fi", year: 2015, rating: 5, poster: "https://image.tmdb.org/t/p/w500/5aGhaIHTONq7T0Fc6VIlN1X6Z3.jpg" }
  ];

  const descriptions = {
    "Avengers Endgame": "The Avengers reunite for their biggest challenge as they try to restore what was lost and protect the universe.",
    "Interstellar": "A science-fiction adventure about astronauts searching for a new home for humanity beyond Earth.",
    "3 Idiots": "Three college friends navigate engineering college, friendship, and the pressure to follow conventional paths.",
    "Titanic": "A romantic drama set aboard the famous ship during its historic voyage across the Atlantic.",
    "The Pursuit of Happyness": "An inspiring drama about a father working hard to build a better future for himself and his son.",
    "Atonement": "A romantic drama about love, misunderstanding, and the long-lasting consequences of one accusation.",
    "Zindagi Na Milegi Dobara": "Three friends take a road trip through Spain and rediscover friendship, courage, and life's possibilities.",
    "Chhichhore": "A comedy-drama about college friends, memories, and learning how to face setbacks together.",
    "Batman v Superman": "Two iconic superheroes clash while a larger threat puts the world in danger.",
    "The Martian": "An astronaut stranded on Mars uses science, ingenuity, and determination to survive until help arrives."
  };

  function readJSON(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      console.warn("MovieHub could not read local data:", error);
      return fallback;
    }
  }

  function getMovies() {
    const saved = readJSON(MOVIES_KEY, null);
    return Array.isArray(saved) ? saved : defaultMovies.slice();
  }

  function getGenres() {
    const saved = readJSON(GENRES_KEY, null);
    return Array.isArray(saved) ? saved : ["Action", "Sci-Fi", "Drama", "Romance", "Comedy", "Adventure"];
  }

  function getAnalytics() {
    const data = readJSON(ANALYTICS_KEY, {});
    return {
      totalVisits: Number(data.totalVisits) || 0,
      dailyVisits: data.dailyVisits && typeof data.dailyVisits === "object" ? data.dailyVisits : {},
      movieViews: data.movieViews && typeof data.movieViews === "object" ? data.movieViews : {}
    };
  }

  function saveAnalytics(data) {
    localStorage.setItem(ANALYTICS_KEY, JSON.stringify(data));
  }

  function todayKey() {
    const d = new Date();
    return [d.getFullYear(), String(d.getMonth() + 1).padStart(2, "0"), String(d.getDate()).padStart(2, "0")].join("-");
  }

  function recordVisit() {
    if (sessionStorage.getItem(VISIT_SESSION_KEY) === "yes") return;
    const data = getAnalytics();
    const today = todayKey();
    data.totalVisits += 1;
    data.dailyVisits[today] = (Number(data.dailyVisits[today]) || 0) + 1;
    saveAnalytics(data);
    sessionStorage.setItem(VISIT_SESSION_KEY, "yes");
  }

  function recordMovieView(title) {
    const data = getAnalytics();
    data.movieViews[title] = (Number(data.movieViews[title]) || 0) + 1;
    saveAnalytics(data);
  }

  function viewCount(title) {
    return Number(getAnalytics().movieViews[title]) || 0;
  }

  function updateVisitorCounter() {
    const data = getAnalytics();
    document.querySelectorAll("[data-visitor-count]").forEach(el => {
      el.textContent = data.totalVisits.toLocaleString("en-IN");
    });
  }

  function stars(value) {
    const n = Math.max(0, Math.min(5, Number(value) || 0));
    return "★".repeat(n) + "☆".repeat(5 - n);
  }

  function makeMovieCard(movie) {
    const card = document.createElement("article");
    card.className = "card";
    card.dataset.name = String(movie.title || "").toLowerCase();
    card.dataset.genre = movie.genre || "";

    const img = document.createElement("img");
    img.src = movie.poster || "https://placehold.co/400x600/1f2937/ffffff?text=Movie+Poster";
    img.alt = (movie.title || "Movie") + " poster";
    img.onerror = function () {
      this.onerror = null;
      this.src = "https://placehold.co/400x600/1f2937/ffffff?text=Movie+Poster";
    };

    const content = document.createElement("div");
    content.className = "card-content";
    const title = document.createElement("h3");
    title.textContent = movie.title || "Untitled Movie";
    const genre = document.createElement("p");
    genre.textContent = "Genre: " + (movie.genre || "Not specified");
    const year = document.createElement("p");
    year.textContent = "Release year: " + (movie.year || "N/A");
    const rating = document.createElement("p");
    rating.className = "rating";
    rating.textContent = stars(movie.rating);
    const views = document.createElement("p");
    views.className = "movie-view-count";
    views.textContent = "Views: " + viewCount(movie.title);
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = "Details";
    button.addEventListener("click", function () { showDetails(movie); });

    content.append(title, genre, year, rating, views, button);
    card.append(img, content);
    return card;
  }

  function renderCards(targetId, movies) {
    const target = document.getElementById(targetId);
    if (!target) return;
    target.replaceChildren();
    if (!movies.length) {
      const empty = document.createElement("p");
      empty.className = "message";
      empty.textContent = "No movies found.";
      target.appendChild(empty);
      return;
    }
    movies.forEach(movie => target.appendChild(makeMovieCard(movie)));
  }

  function sortByViews(movies) {
    return movies.slice().sort((a, b) => {
      const diff = viewCount(b.title) - viewCount(a.title);
      return diff || (Number(b.rating) || 0) - (Number(a.rating) || 0) || String(a.title).localeCompare(String(b.title));
    });
  }

  function showDetails(movie) {
    recordMovieView(movie.title);
    updateVisitorCounter();
    renderAllMovieLists();
    const modal = document.getElementById("movieModal");
    if (!modal) return;
    const title = document.getElementById("detailTitle");
    const info = document.getElementById("detailInfo");
    const description = document.getElementById("detailDescription");
    if (title) title.textContent = movie.title;
    if (info) info.textContent = "Genre: " + (movie.genre || "N/A") + " | Release year: " + (movie.year || "N/A") + " | Rating: " + stars(movie.rating) + " | Views: " + viewCount(movie.title);
    if (description) description.textContent = movie.description || descriptions[movie.title] || "Movie details are not available yet.";
    modal.style.display = "flex";
  }

  function renderAllMovieLists() {
    const movies = getMovies();
    if (document.getElementById("movieList")) renderCards("movieList", movies);
    if (document.getElementById("mostViewedList")) renderCards("mostViewedList", sortByViews(movies).slice(0, 5));
    if (document.getElementById("trendingList")) renderCards("trendingList", sortByViews(movies));
    if (document.getElementById("genreMovieList")) renderGenreMovies(activeGenre, movies);
  }

  let activeGenre = "";
  function populateGenreSelect(id, placeholder) {
    const select = document.getElementById(id);
    if (!select) return;
    select.replaceChildren();
    const first = document.createElement("option");
    first.value = "";
    first.textContent = placeholder;
    select.appendChild(first);
    getGenres().forEach(genre => {
      const option = document.createElement("option");
      option.value = genre;
      option.textContent = genre;
      select.appendChild(option);
    });
  }

  function renderGenreButtons() {
    const target = document.getElementById("genreButtons");
    if (!target) return;
    target.replaceChildren();
    const allButton = document.createElement("button");
    allButton.className = "genre-chip";
    allButton.textContent = "All";
    allButton.addEventListener("click", () => { activeGenre = ""; renderGenreMovies(activeGenre); });
    target.appendChild(allButton);
    getGenres().forEach(genre => {
      const button = document.createElement("button");
      button.className = "genre-chip";
      button.textContent = genre;
      button.addEventListener("click", () => { activeGenre = genre; renderGenreMovies(activeGenre); });
      target.appendChild(button);
    });
  }

  function renderGenreMovies(genre, movieList) {
    const all = movieList || getMovies();
    const filtered = genre ? all.filter(movie => movie.genre === genre) : all;
    renderCards("genreMovieList", filtered);
  }

  function filterHomeMovies() {
    const search = (document.getElementById("movieSearch")?.value || "").trim().toLowerCase();
    const genre = document.getElementById("genreSelect")?.value || "";
    const filtered = getMovies().filter(movie => String(movie.title).toLowerCase().includes(search) && (!genre || movie.genre === genre));
    renderCards("movieList", filtered);
  }

  function recommendMovie() {
    const genre = document.getElementById("genreSelect")?.value || "";
    const result = document.getElementById("recommendation");
    if (!result) return;
    if (!genre) {
      result.textContent = "Please select a genre first.";
      return;
    }
    const match = getMovies().find(movie => movie.genre === genre);
    result.textContent = match ? "Recommended movie: " + match.title : "No recommendation is available for this genre yet.";
  }

  function clearFilters() {
    const search = document.getElementById("movieSearch");
    const genre = document.getElementById("genreSelect");
    const result = document.getElementById("recommendation");
    if (search) search.value = "";
    if (genre) genre.value = "";
    if (result) result.textContent = "";
    filterHomeMovies();
  }

  function closeDetails() {
    const modal = document.getElementById("movieModal");
    if (modal) modal.style.display = "none";
  }

  document.addEventListener("DOMContentLoaded", function () {
    recordVisit();
    updateVisitorCounter();
    populateGenreSelect("genreSelect", "All genres");
    populateGenreSelect("favGenre", "Choose your favourite genre");
    renderAllMovieLists();
    renderGenreButtons();
    const search = document.getElementById("movieSearch");
    const genre = document.getElementById("genreSelect");
    const recommend = document.getElementById("recommendButton");
    const clear = document.getElementById("clearButton");
    if (search) search.addEventListener("input", filterHomeMovies);
    if (genre) genre.addEventListener("change", filterHomeMovies);
    if (recommend) recommend.addEventListener("click", recommendMovie);
    if (clear) clear.addEventListener("click", clearFilters);
    const modal = document.getElementById("movieModal");
    if (modal) modal.addEventListener("click", event => { if (event.target === modal) closeDetails(); });
    document.querySelectorAll("[data-close-modal]").forEach(button => button.addEventListener("click", closeDetails));
  });

  window.MovieHub = {
    getMovies,
    getGenres,
    getAnalytics,
    getViewCount: viewCount,
    recordMovieView,
    updateVisitorCounter,
    renderAllMovieLists
  };
})();
