// Shows the signed-in user's email and provides a simple demo logout link.
document.addEventListener('DOMContentLoaded', function () {
  const authLink = document.querySelector('[data-user-auth]');
  const signedInUser = sessionStorage.getItem('moviehubUser');
  if (!authLink || !signedInUser) return;
  authLink.textContent = 'Logout';
  authLink.href = '#';
  authLink.addEventListener('click', function (event) {
    event.preventDefault();
    sessionStorage.removeItem('moviehubUser');
    window.location.reload();
  });
});
